package middleware

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/quran-school/api/internal/model"
)

// canWrite returns true for roles allowed to mutate data.
func canWrite(role string) bool {
	return role == model.RoleSuperAdmin || role == model.RoleSchoolAdmin
}

// RequireWrite aborts with 403 unless the caller is school_admin or super_admin.
// Must be chained after RequireAuth.
func RequireWrite() gin.HandlerFunc {
	return func(c *gin.Context) {
		user := UserFrom(c)
		if user == nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "unauthenticated"})
			return
		}
		if !canWrite(user.Role) {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
				"error": "write access requires school_admin or super_admin role",
			})
			return
		}
		c.Next()
	}
}

// RequireNotAccountant aborts with 403 for accountant role.
// Accountants have no access to students/groups.
func RequireNotAccountant() gin.HandlerFunc {
	return func(c *gin.Context) {
		user := UserFrom(c)
		if user == nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "unauthenticated"})
			return
		}
		if user.Role == model.RoleAccountant {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
				"error": "accountants do not have access to students or groups",
			})
			return
		}
		c.Next()
	}
}

// SchoolIDFrom returns the school UUID from the Gin context (set by RequireAuth).
// Returns uuid.Nil and false for super_admin (school_id is empty string → no restriction).
// Handlers that need a concrete school_id should call this and handle the super_admin case.
