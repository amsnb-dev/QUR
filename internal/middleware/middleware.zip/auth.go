package middleware

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/quran-school/api/internal/auth"
	"github.com/quran-school/api/internal/db"
	"github.com/quran-school/api/internal/model"
)

const (
	ctxUser     = "user"
	ctxTx       = "tx"
	ctxSchoolID = "school_id_str"
)

// RequireAuth validates the Bearer JWT, opens a tenant-scoped transaction
// (SET LOCAL app.school_id), and stores user + tx on the Gin context.
func RequireAuth(svc *auth.Service, pool *db.Pool) gin.HandlerFunc {
	return func(c *gin.Context) {
		header := c.GetHeader("Authorization")
		if header == "" || !strings.HasPrefix(header, "Bearer ") {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"error": "missing or malformed Authorization header",
			})
			return
		}
		tokenStr := strings.TrimPrefix(header, "Bearer ")

		claims, err := svc.ParseAccessToken(tokenStr)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"error": "invalid or expired token",
			})
			return
		}

		userID, err := uuid.Parse(claims.UserID)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"error": "malformed user id in token",
			})
			return
		}

		user := &model.User{ID: userID, Role: claims.Role}

		// schoolIDStr is "" for super_admin → RLS allows full access
		schoolIDStr := ""
		if claims.SchoolID != nil {
			schoolIDStr = *claims.SchoolID
			sid, err := uuid.Parse(schoolIDStr)
			if err != nil {
				c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
					"error": "malformed school id in token",
				})
				return
			}
			user.SchoolID = &sid
		}

		// Open tenant-scoped transaction: SET LOCAL app.school_id = '...'
		tx, err := pool.TxWithTenant(c.Request.Context(), schoolIDStr)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
				"error": "database error",
			})
			return
		}

		c.Set(ctxUser, user)
		c.Set(ctxTx, tx)
		c.Set(ctxSchoolID, schoolIDStr)

		c.Next()

		// Commit on success, rollback on any 4xx/5xx
		if c.Writer.Status() < 400 {
			_ = tx.Commit(c.Request.Context())
		} else {
			_ = tx.Rollback(c.Request.Context())
		}
	}
}

// UserFrom retrieves the authenticated user stored by RequireAuth.
func UserFrom(c *gin.Context) *model.User {
	v, _ := c.Get(ctxUser)
	u, _ := v.(*model.User)
	return u
}

// TxFrom retrieves the tenant-scoped pgx.Tx stored by RequireAuth.
func TxFrom(c *gin.Context) pgx.Tx {
	v, _ := c.Get(ctxTx)
	tx, _ := v.(pgx.Tx)
	return tx
}

// RequireRole aborts with 403 if the caller's role is not in the allowed list.
// Must be used after RequireAuth.
func RequireRole(roles ...string) gin.HandlerFunc {
	allowed := make(map[string]struct{}, len(roles))
	for _, r := range roles {
		allowed[r] = struct{}{}
	}
	return func(c *gin.Context) {
		user := UserFrom(c)
		if user == nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "unauthenticated"})
			return
		}
		if _, ok := allowed[user.Role]; !ok {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
				"error": "insufficient permissions",
			})
			return
		}
		c.Next()
	}
}
